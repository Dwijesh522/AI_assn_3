# run only clause generator
./clause_generator_version2 $1
