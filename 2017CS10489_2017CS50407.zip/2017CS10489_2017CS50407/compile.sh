# compile all files together.
g++ clause_generator_version2.cpp -o clause_generator_version2 -std=c++11
g++ mapping_generator.cpp -o mapping_generator -std=c++11
