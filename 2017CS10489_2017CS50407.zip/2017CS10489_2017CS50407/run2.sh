./mapping_generator $1
